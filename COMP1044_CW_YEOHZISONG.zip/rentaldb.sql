-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 21, 2022 at 03:26 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rentaldb`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `CustomerID` int(12) NOT NULL,
  `FirstName` varchar(80) NOT NULL,
  `LastName` varchar(80) NOT NULL,
  `Gender` varchar(80) NOT NULL,
  `Age` int(12) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `ContactNumber` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CustomerID`, `FirstName`, `LastName`, `Gender`, `Age`, `Email`, `ContactNumber`) VALUES
(102, 'Tami', 'Dawson', 'M', 23, 'tami@gmail.com', '+6011-88899413'),
(103, 'Curt', 'Knight', 'M', 45, 'CKnight@hotmail.com', '+6015-20911593'),
(104, 'Jamal', 'Melendez', 'F', 32, 'wajoler@gmail.com', '+6011-88892506'),
(105, 'Iva', 'Mcclain', 'M', 35, 'tellabefri@ymail.com', '+6011-88867648'),
(106, 'Miranda', 'Parks', 'M', 27, 'jammois@yahoo.com', '+6010-3222168'),
(107, 'Rosario', 'Elliott', 'F', 21, 'queppau@gmail.com', '+6010-4576352'),
(108, 'Mattie', 'Guy', 'F', 39, 'jacuvagoi@gmail.com', '+6011-60909891'),
(109, 'Clint', 'Ochoa', 'F', 54, 'poikezipa@outlook.com', '+6011-69624308'),
(110, 'Lewis', 'Rosales', 'M', 27, 'croteuti@yopmail.com', '+6010-4552136'),
(111, 'Stacy', 'Mann', 'F', 36, 'quopattu@yahoo.com', '+6018-1251684'),
(112, 'Luis', 'Trujillo', 'F', 55, 'greipram@outlook.com', '+6011-88862152'),
(113, 'Minnie', 'Gonzales', 'F', 40, 'bauweddolo@gmail.com', '+6014-4004835');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `ReservationID` int(12) NOT NULL,
  `ReservationDate` date NOT NULL,
  `StartTime` time(5) NOT NULL,
  `EndTime` time(5) NOT NULL,
  `VehicleID` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`ReservationID`, `ReservationDate`, `StartTime`, `EndTime`, `VehicleID`) VALUES
(34341, '2021-07-16', '10:00:00.00000', '13:00:00.00000', 'V1003'),
(34342, '2022-01-17', '16:00:00.00000', '17:00:00.00000', 'V1011'),
(34366, '2022-01-10', '09:00:00.00000', '12:00:00.00000', 'V1002'),
(34367, '2021-09-18', '13:00:00.00000', '15:00:00.00000', 'V1002'),
(34368, '2022-01-10', '11:00:00.00000', '14:00:00.00000', 'V1001'),
(34369, '2022-02-01', '09:00:00.00000', '11:00:00.00000', 'V1003'),
(44392, '2022-02-13', '11:00:00.00000', '14:00:00.00000', 'V1006'),
(44397, '2021-12-15', '13:00:00.00000', '17:00:00.00000', 'V1005'),
(54321, '2022-01-15', '13:00:00.00000', '14:00:00.00000', 'V1003'),
(54324, '2022-02-08', '09:00:00.00000', '11:00:00.00000', 'V1001'),
(54325, '2022-02-11', '12:00:00.00000', '14:00:00.00000', 'V1010'),
(59237, '2022-01-03', '14:00:00.00000', '16:00:00.00000', 'V1007');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `StaffID` varchar(80) NOT NULL,
  `FirstName` varchar(80) NOT NULL,
  `LastName` varchar(80) NOT NULL,
  `Password` varchar(80) NOT NULL,
  `Role` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`StaffID`, `FirstName`, `LastName`, `Password`, `Role`) VALUES
('S1001', 'Vijaya', 'Daiva', 'S1001', 'Manager'),
('S1002', 'Colby', 'Pranav', 'S1002', 'Employee'),
('S1003', 'Amalia', 'Cadmus', 'S1003', 'Manager'),
('S1004', 'Helen', 'Chadana', 'S1004', 'Employee'),
('S1005', 'Sabrina', 'Suri', 'S1005', 'Employee'),
('S1006', 'Allard', 'Tihomir', 'S1006', 'Manager'),
('S1007', 'Teodora', 'Cyprien', 'S1007', 'Manager'),
('S1008', 'Ozihel', 'Morwen', 'S1008', 'Manager'),
('S1009', 'Merton', 'Wanda', 'S1009', 'Employee'),
('S1010', 'Ayelen', 'Caesonius', 'S1010', 'Manager');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `TransactionID` varchar(80) NOT NULL,
  `Duration` int(12) NOT NULL,
  `Amount` int(12) NOT NULL,
  `TransactionDate` date NOT NULL,
  `ReservationID` int(12) NOT NULL,
  `CustomerID` int(12) NOT NULL,
  `StaffID` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`TransactionID`, `Duration`, `Amount`, `TransactionDate`, `ReservationID`, `CustomerID`, `StaffID`) VALUES
('TR1231', 1, 180, '2022-01-10', 54321, 103, 'S1009'),
('TR1235', 2, 1960, '2022-02-07', 54324, 107, 'S1002'),
('TR1236', 2, 640, '2022-01-11', 54325, 105, 'S1003'),
('TR1237', 3, 180, '2021-06-11', 34341, 106, 'S1007'),
('TR1238', 1, 260, '2022-01-02', 34342, 107, 'S1010'),
('TR1239', 3, 1440, '2022-01-03', 34366, 108, 'S1002'),
('TR1245', 2, 960, '2021-07-13', 34367, 107, 'S1003'),
('TR1246', 3, 2940, '2022-01-05', 34368, 103, 'S1010'),
('TR1247', 2, 360, '2022-01-24', 34369, 104, 'S1007'),
('TR1248', 3, 2100, '2022-02-11', 44392, 106, 'S1001'),
('TR1249', 4, 2400, '2021-11-15', 44397, 107, 'S1002'),
('TR1250', 2, 560, '2022-01-02', 59237, 102, 'S1004');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `VehicleID` varchar(12) NOT NULL,
  `VehicleModel` varchar(80) NOT NULL,
  `VehicleType` varchar(80) NOT NULL,
  `RentalPrice` int(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`VehicleID`, `VehicleModel`, `VehicleType`, `RentalPrice`) VALUES
('V1001', 'Rolls Royce Phantom', 'Luxury', 980),
('V1002', 'Bentley Continental Flying Spur', 'Luxury', 480),
('V1003', 'Mercedes Benz CLS 350', 'Luxury', 180),
('V1004', 'Jaguar S Type', 'Luxury', 190),
('V1005', 'Ferrari F430 Scuderia', 'Sports', 600),
('V1006', 'Lamborghini Murcielago LP640', 'Sports', 700),
('V1007', 'Porsche Boxster', 'Sports', 280),
('V1008', 'Lexus SC430', 'Sports', 180),
('V1009', 'Jaguar MK 2', 'Classics', 230),
('V1010', 'Rolls Royce Silver Spirit Limousine', 'Classics', 320),
('V1011', 'MG T', 'Classics', 260);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`CustomerID`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`ReservationID`),
  ADD KEY `VehicleID` (`VehicleID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`StaffID`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`TransactionID`),
  ADD KEY `ReservationID` (`ReservationID`),
  ADD KEY `CustomerID` (`CustomerID`),
  ADD KEY `StaffID` (`StaffID`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`VehicleID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `CustomerID` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`VehicleID`) REFERENCES `vehicle` (`VehicleID`);

--
-- Constraints for table `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`ReservationID`) REFERENCES `reservation` (`ReservationID`),
  ADD CONSTRAINT `transaction_ibfk_2` FOREIGN KEY (`CustomerID`) REFERENCES `customer` (`CustomerID`),
  ADD CONSTRAINT `transaction_ibfk_3` FOREIGN KEY (`StaffID`) REFERENCES `staff` (`StaffID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
