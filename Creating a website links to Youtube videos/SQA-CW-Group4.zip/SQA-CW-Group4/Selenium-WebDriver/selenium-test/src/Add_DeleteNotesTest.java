import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class Add_DeleteNotesTest {
    private WebDriver driver;
    public WebDriverWait wait;

    @Before
    public void setUp() {

        System.setProperty("webdriver.chrome.driver", "chromedriver/chromedriver.exe");
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(5));

    }

    @Test
    public void takeNotesWhileNotPaused() throws InterruptedException {

        String workingDir = "https://hueygwen.github.io/UNM-SQA-2023-24/";
        String videoID = "xtQpNdGK6WI";

        driver.get(workingDir + "iFrame.html?videoID=" + videoID);

        WebElement playVideo = driver.findElement(By.id("player"));
        playVideo.click();

        // Find input field and enter text test
        WebElement noteInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("note-input")));
        noteInput.sendKeys("This is a test note for " + videoID);

        Thread.sleep(3000);

        // Find add btn and click test
        WebElement addNoteButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("add-note-btn")));

        // Scroll into view
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", addNoteButton);

        Thread.sleep(3000);

        // if normal click is not working, the javascript should click it
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", addNoteButton);

        Thread.sleep(3000);

        // Verify that the note was added
        WebElement addedNote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
                "//ul[@id='notes-list']/li[contains(text(), '" + "This is a test note for " + videoID + "')]")));
        assertTrue("Note should have been added", addedNote.isDisplayed());

        String noteText = addedNote.getText();
        if (noteText.contains("This is a test note" + videoID)) {
            System.out.println("Note added successfully for video ID: " + videoID);
        } else {
            System.out.println("Note not added or incorrect note for video ID: " + videoID);
        }

        Thread.sleep(3000);

    }

    @Test
    public void testAddDeleteNotes() {
        // Testing two different video IDs to ensure the notes
        // from one doesn't go to the other one
        List<String> videoIDs = Arrays.asList(
                "xtQpNdGK6WI",
                "u6QfIXgjwGQ");
        try {
            for (String videoID : videoIDs) {
                // build video url based on ID

                String workingDir = "https://hueygwen.github.io/UNM-SQA-2023-24/";
                String videoURL = workingDir + "iFrame.html?videoID=" + videoID;
                driver.get(videoURL); // open page

                Thread.sleep(3000);

                // Find input field and enter text test
                WebElement noteInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("note-input")));
                noteInput.sendKeys("This is a test note" + videoID);

                Thread.sleep(3000);

                // Find add btn and click test
                WebElement addNoteButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("add-note-btn")));

                // Scroll into view
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", addNoteButton);

                // if normal click is not working, the javascript should click it
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", addNoteButton);

                Thread.sleep(3000);

                // Verify that the note was added
                WebElement addedNote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
                        "//ul[@id='notes-list']/li[contains(text(), '" + "This is a test note" + videoID + "')]")));
                assertTrue("Note should have been added", addedNote.isDisplayed());

                String noteText = addedNote.getText();
                if (noteText.contains("This is a test note" + videoID)) {
                    System.out.println("Note added successfully for video ID: " + videoID);
                } else {
                    System.out.println("Note not added or incorrect note for video ID: " + videoID);
                }

                Thread.sleep(3000);

                // Delete the note
                WebElement deleteButton = wait.until(ExpectedConditions.elementToBeClickable(
                        By.xpath("//ul[@id='notes-list']/li[contains(text(), '" + "This is a test note" + videoID
                                + "')]/button[contains(@class, 'delete-note-btn')]")));

                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", deleteButton);
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", deleteButton);

                // Wait for the note to be removed
                wait.until(ExpectedConditions.invisibilityOf(addedNote));

                Thread.sleep(3000);

                // Verify the note is deleted
                List<WebElement> notes = driver.findElements(By.xpath("//li[contains(text(), '" + noteText + "')]"));
                assertTrue("The test note was successfully deleted.", notes.isEmpty());
                if (notes.isEmpty()) {
                    System.out.println("The test note was successfully deleted.");
                } else {
                    System.out.println("The test note is still present after attempting to delete.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @After
    public void tearDown() {
        driver.quit();
    }
}
