
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class DownloadNotesTest {

    private WebDriver driver;

    @Before
    public void setUp() {

        System.setProperty("webdriver.chrome.driver", "chromedriver/chromedriver.exe");
        driver = new ChromeDriver();

        String workingDir = "https://hueygwen.github.io/UNM-SQA-2023-24/";

        driver.get(workingDir + "Home.html");

    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    // Test for file naming convention "notes_<videoID>.txt"
    @Test
    public void testFileName() {
        try {
            // Click on a video
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
            WebElement videoLink = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".youtube-link")));
            videoLink.click();

            // Wait for the iframe.html page to load
            WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(30));
            wait1.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(0));

            // Get the video ID from the URL
            String currentUrl = driver.getCurrentUrl();
            String videoID = currentUrl.split("=")[1];

            driver.switchTo().defaultContent();
            WebElement downloadNotesButton = driver.findElement(By.id("download-notes-btn"));

            // Click on the "Download Notes" button using JavaScript
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", downloadNotesButton);

            // Wait for a few seconds to ensure the download has started
            Thread.sleep(5000);

            // Construct the base path using the user's home directory
            String basePath = System.getProperty("user.home") + File.separator + "Downloads";

            // Get the actual filename from the downloaded file
            String actualFileName = getDownloadedFileName(basePath);

            // Verify the filename
            assertTrue("File name verification failed!", verifyFileName(actualFileName, videoID));

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue("File name verification test failed!", false);
        }
    }

    private String getDownloadedFileName(String basePath) {
        File downloadsFolder = new File(basePath);
        File[] files = downloadsFolder.listFiles();

        if (files != null && files.length > 0) {
            // Sort files by last modified timestamp in descending order
            Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());

            // Assuming the first (latest) file is the downloaded file
            return files[0].getName();
        } else {
            System.err.println("No files found in the Downloads folder.");
            return "";
        }
    }

    private boolean verifyFileName(String actualFileName, String expectedVideoID) {
        // Ensure that the file name is not empty
        if (!actualFileName.isEmpty()) {
            String actualFileNameWithoutNumbering = actualFileName.replaceAll(" \\(\\d+\\)", "");

            // Construct the expected filename pattern
            String expectedFileNamePattern = "notes_" + expectedVideoID + ".txt";

            // Verify the file name (case-insensitive)
            return actualFileNameWithoutNumbering.equalsIgnoreCase(expectedFileNamePattern);
        } else {
            System.err.println("Downloaded file name is empty.");
            return false;
        }
    }

    // Test for download notes button
    @Test
    public void testDownloadNotes() {
        try {

            // Click on a video
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
            WebElement videoLink = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".youtube-link")));
            videoLink.click();

            // Wait for the iframe.html page to load
            WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(30));
            wait1.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(0));

            driver.switchTo().defaultContent();
            WebElement downloadNotesButton = driver.findElement(By.id("download-notes-btn"));

            // Click on the "Download Notes" button using JavaScript
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", downloadNotesButton);

            // Wait for a few seconds to ensure the download has started
            Thread.sleep(5000);

            // Assuming the download is successful if no exception is thrown
            assertTrue(true);

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue("Download test failed!", false);
        }
    }

    // Test to make sure notes downloaded are as displayed base on video ID
    @Test
    public void testFileContent() {
        try {
            // Click on a video
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
            WebElement videoLink = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".youtube-link")));
            videoLink.click();

            // Wait for the iframe.html page to load
            WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(30));
            wait1.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(0));

            // Get the video ID from the URL
            String currentUrl = driver.getCurrentUrl();
            String videoID = currentUrl.split("=")[1];

            driver.switchTo().defaultContent();
            WebElement downloadNotesButton = driver.findElement(By.id("download-notes-btn"));

            // Click on the "Download Notes" button using JavaScript
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", downloadNotesButton);

            // Wait for a few seconds to ensure the download has started
            Thread.sleep(5000);

            // Construct the base path using the user's home directory
            String basePath = System.getProperty("user.home") + File.separator + "Downloads";

            // Specify the relative path within the Downloads folder
            String relativePath = "notes_" + videoID + ".txt";

            // Construct the full file path
            String filePath = basePath + File.separator + relativePath;

            System.out.println(filePath);

            // Read the content of the downloaded file
            List<String> fileContent = readFileContent(filePath);

            // Verify the content
            assertTrue("File content verification failed!", verifyFileContent(fileContent, videoID));

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue("File content verification test failed!", false);
        }
    }

    private List<String> readFileContent(String filePath) {
        List<String> content = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                content.add(line);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return content;
    }

    private boolean verifyFileContent(List<String> fileContent, String expectedVideoID) {
        // Ensure that the file content is not empty
        if (fileContent.isEmpty()) {
            return false;
        }

        // Extract the video ID from the first line (assuming it's the YouTube video
        // URL)
        String actualVideoID = extractVideoID(fileContent.get(0));

        // Compare the actual and expected video IDs
        return actualVideoID.equals(expectedVideoID);
    }

    private String extractVideoID(String youtubeVideoUrl) {
        // Your logic to extract the video ID from the YouTube video URL
        // For simplicity, let's assume the video ID is the part after the last '='
        int lastIndex = youtubeVideoUrl.lastIndexOf('=');
        return lastIndex != -1 ? youtubeVideoUrl.substring(lastIndex + 1) : "";
    }

}
