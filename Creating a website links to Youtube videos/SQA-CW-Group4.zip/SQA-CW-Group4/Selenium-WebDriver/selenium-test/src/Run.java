import java.lang.reflect.Method;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.devtools.v117.indexeddb.model.Key;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

//import NavigateToHomePage.NavigateToHomePage;

import org.openqa.selenium.interactions.Actions;

import dev.failsafe.internal.util.Assert;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runner.RunWith;
import org.junit.runner.notification.Failure;
import org.junit.runners.Suite;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import static org.junit.Assert.*;

public class Run {
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "chromedriver/chromedriver.exe");
        new ChromeDriver();
    }

    public static void runAllMethods(Object instance) throws InterruptedException {
        Method[] methods = instance.getClass().getDeclaredMethods();

        for (Method method : methods) {
            try {
                // Make sure the method is accessible
                method.setAccessible(true);
                // Invoke the method only if it has no parameters
                if (method.getParameterCount() == 0) {
                    method.invoke(instance);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        // Run the test suite
        Result result = JUnitCore.runClasses(SeleniumTestSuite.class);

        // Process and print the test results
        for (Failure failure : result.getFailures()) {
            System.out.println(failure.toString());
        }

        System.out.println("Successful: " + result.wasSuccessful());
    }

    @RunWith(Suite.class)
    @Suite.SuiteClasses({

            NavigateToHomePage.class,
            NavigateToPlayer.class,
            YoutubeSearchTest.class,
            Add_DeleteNotesTest.class,
            DownloadNotesTest.class

    })

    public class SeleniumTestSuite {

    }
}
