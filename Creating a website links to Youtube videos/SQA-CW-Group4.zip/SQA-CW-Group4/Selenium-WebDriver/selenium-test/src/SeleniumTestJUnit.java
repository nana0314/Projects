import static org.junit.Assert.*;

import java.time.Duration;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleniumTestJUnit {

    private WebDriver driver;

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver",
                "chromedriver/chromedriver.exe");
        driver = new ChromeDriver();
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    public void testDownloadNotes() {
        try {
            // Open Home.html

            String workingDir = "https://hueygwen.github.io/UNM-SQA-2023-24/";
            driver.get(workingDir + "Home.html");
            System.out.println("Opened Home.html successfully.");

            // Click on a video
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
            WebElement videoLink = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".youtube-link")));
            videoLink.click();

            System.out.println("Clicked on a video link.");

            // Wait for the iframe.html page to load
            WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(30));
            wait1.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(0));
            System.out.println("Switched to iframe successfully.");

            // Get the video ID from the URL
            String currentUrl = driver.getCurrentUrl();
            String videoID = currentUrl.split("=")[1];
            System.out.println("Video ID from URL: " + videoID);

            driver.switchTo().defaultContent();
            WebElement downloadNotesButton = driver.findElement(By.id("download-notes-btn"));
            System.out.println("Button found");

            // Click on the "Download Notes" button using JavaScript
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", downloadNotesButton);
            System.out.println("Note downloaded!");

            // Wait for a few seconds to ensure the download has started
            Thread.sleep(5000);

            // Assuming the download is successful if no exception is thrown
            assertTrue(true);

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue("Download test failed!", false);
        }
    }
}