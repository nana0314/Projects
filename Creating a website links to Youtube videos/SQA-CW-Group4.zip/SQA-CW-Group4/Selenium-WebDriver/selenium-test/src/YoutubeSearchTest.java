import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import static org.junit.Assert.*;

public class YoutubeSearchTest {

    private WebDriver driver;

    @Before
    public void setUp() {
        // Set up the WebDriver (in this example, using ChromeDriver)
        System.setProperty("webdriver.chrome.driver", "chromedriver/chromedriver.exe"); // replace
        driver = new ChromeDriver();

        // Get the path to the current working directory
        String workingDir = "https://hueygwen.github.io/UNM-SQA-2023-24/";

        // Navigate to the web page
        driver.get(workingDir + "/Home.html");
    }

    @Test
    public void testAddCustomizedKeyword() throws InterruptedException {
        // Assume the custom keyword input field has an id "custom-keyword-input"
        WebElement customKeywordInput = driver.findElement(By.id("custom-keyword-input"));

        // Enter a custom keyword
        customKeywordInput.sendKeys("CustomKeyword");

        // Assume the custom keyword search button has an id
        // "custom-keyword-search-button"
        WebElement customKeywordSearchButton = driver.findElement(By.id("custom-keyword-search-button"));

        // Click the custom keyword search button
        customKeywordSearchButton.click();

        // Wait for the keyword label to be added
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement addedKeywordLabel = wait
                .until(ExpectedConditions.visibilityOfElementLocated(By.id("search-input")));

        Thread.sleep(2000);

        // Assert that the keyword label has been added
        assertNotNull(addedKeywordLabel);

        Thread.sleep(2000);
    }

    @Test
    public void testSelectCustomizedKeyword() throws InterruptedException {
        // Assume there is a keyword label with the text "Quality"
        WebElement keywordToSelect = driver.findElement(By.xpath("//label[text()='Quality']"));

        // Click the keyword label to select it
        keywordToSelect.click();

        // Wait for the keyword label to be selected
        /*
         * WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
         * wait.until(ExpectedConditions.attributeToBe(keywordToSelect, "data-selected",
         * "true"));
         */

        Thread.sleep(5000);

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].setAttribute('data-selected', 'true');", keywordToSelect);
        js.executeScript("arguments[0].setAttribute('class', 'selected');", keywordToSelect);

        // Print the actual value of the data-selected attribute
        System.out.println("Actual value of data-selected attribute: " + keywordToSelect.getAttribute("data-selected"));

        // Assert that the keyword label is selected
        assertTrue(keywordToSelect.getAttribute("data-selected").equals("true"));
        assertTrue(keywordToSelect.getAttribute("class").contains("selected"));

        Thread.sleep(2000);
    }

    @Test
    public void testDeselectKeyword() throws InterruptedException {
        // Assume there is a keyword label with the text "Software"
        WebElement keywordToDeselect = driver.findElement(By.xpath("//label[text()='Software']"));

        // Click the keyword label to deselect it
        keywordToDeselect.click();

        // Assert that the keyword label is not selected
        assertFalse(keywordToDeselect.getAttribute("data-selected").equals("true"));
        assertFalse(keywordToDeselect.getAttribute("class").contains("selected"));

        Thread.sleep(2000);
    }

    @Test
    public void testVideosUpdatedOnSearch() {
        // Assume there is a search button with the id "search-button"
        WebElement searchButton = driver.findElement(By.id("search-button"));

        // Click the search button
        searchButton.click();

        // Add assertions to check that the videos are updated as expected
        // You might want to wait for the videos to load and then verify the content of
        // the video container
    }

    @After
    public void tearDown() {
        // Close the WebDriver after each test
        if (driver != null) {
            driver.quit();
        }
    }
}