HOW TO OPEN THE GAME?

1. Open Control-Alt-Hack 2.0 file
2. Open Control-Alt-Hack 2.0 exe/application file and ENJOY!

Note: 
Make sure to have the game on FULLSCREEN mode to see/read the elements of the game properly
If the game starts as WINDOWED,
ALT+ENTER to change between WINDOWED and FULLSCREEN

Group F's Github: https://github.com/lionggele/ControlAltHack2.0