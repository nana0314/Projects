import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import dev.failsafe.internal.util.Assert;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class NavigateToHomePage {

    private WebDriver driver;

    @Before
    public void setUp() {

        System.setProperty("webdriver.chrome.driver", "chromedriver/chromedriver.exe");
        driver = new ChromeDriver();

        String workingDir = "https://hueygwen.github.io/UNM-SQA-2023-24/";
        String videoID = "xtQpNdGK6WI";

        driver.get(workingDir + "iFrame.html?videoID=" + videoID);

    }

    @Test
    public void backToHomeLogo() throws InterruptedException {
        Thread.sleep(5000);
        driver.findElement(By.className("university-logo")).click();
        Thread.sleep(2000);

        String homeUrl = driver.getCurrentUrl();
        String[] destinationPage = homeUrl.split("/");
        String homeFileName = destinationPage[destinationPage.length - 1];

        assertEquals("Home.html", homeFileName);

        driver.quit();
    }

    @Test
    public void backToHomeButton() throws InterruptedException {
        Thread.sleep(5000);
        driver.findElement(By.className("home-button")).click();
        Thread.sleep(2000);

        String homeUrl = driver.getCurrentUrl();
        String[] destinationPage = homeUrl.split("/");
        String homeFileName = destinationPage[destinationPage.length - 1];

        assertEquals("Home.html", homeFileName);

        driver.quit();
    }

    @Test
    public void clickSuggestedVideos() throws InterruptedException {
        Thread.sleep(2000);

        List<WebElement> suggestedVideo = driver.findElements(By.className("suggest-video-row"));

        if (suggestedVideo.size() > 0) {
            WebElement chooseOneSuggested = suggestedVideo.get(2);
            chooseOneSuggested.click();

            Thread.sleep(2000);
        } else {
            System.out.println("No suggested videos were found");
        }
    }

    @After
    public void tearDown() {
        driver.quit();
    }

}
