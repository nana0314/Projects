import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.devtools.v117.indexeddb.model.Key;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.interactions.Actions;

import dev.failsafe.internal.util.Assert;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class NavigateToPlayer {

    private WebDriver driver;
    public WebDriverWait wait;

    @Before
    public void setUp() {

        System.setProperty("webdriver.chrome.driver", "chromedriver/chromedriver.exe");
        driver = new ChromeDriver();

        String workingDir = "https://hueygwen.github.io/UNM-SQA-2023-24/";

        driver.get(workingDir + "Home.html");

    }

    @Test
    public void clickOneVideoAndControlPlayer() throws InterruptedException {
        Thread.sleep(2000);

        List<WebElement> youtubeLinks = driver.findElements(By.className("youtube-link"));

        if (youtubeLinks.size() > 0) {
            WebElement chooseFirstVideo = youtubeLinks.get(0);
            chooseFirstVideo.click();

            // Create an Actions object
            // Actions actions = new Actions(driver);

            WebElement videoPlayer = driver.findElement(By.id("player"));

            Thread.sleep(3000);
            videoPlayer.click();

            videoPlayer.sendKeys(Keys.SPACE);
            videoPlayer.click(); // regain focus

            Thread.sleep(2000);

            videoPlayer.sendKeys("m");
            videoPlayer.click(); // regain focus

            Thread.sleep(2000);

            videoPlayer.sendKeys("m");
            videoPlayer.click(); // regain focus

            Thread.sleep(2000);

            videoPlayer.sendKeys(Keys.ARROW_LEFT);
            videoPlayer.click(); // regain focus

            Thread.sleep(2000);

            videoPlayer.sendKeys(Keys.ARROW_RIGHT);
            videoPlayer.click(); // regain focus

            Thread.sleep(2000);

            videoPlayer.sendKeys(Keys.ARROW_UP);
            videoPlayer.click(); // regain focus

            Thread.sleep(2000);

            videoPlayer.sendKeys(Keys.ARROW_DOWN);
            videoPlayer.click();

        } else {
            System.out.println("\nNo video links found in homepage.");
        }

    }

    @After
    public void tearDown() {
        driver.quit();
    }
}