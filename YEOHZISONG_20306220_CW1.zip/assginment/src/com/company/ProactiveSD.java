package com.company;
import java.util.Scanner; //importing scanner for input function
import java.util.Random; //importing random generator
class LocationDatabase { //task 1 class to display locations. whereas id represents as floor levels of sunway pyramid
    public void display1() { //first floor of sunway pyramid //YEOHZISONG
        int id, area, capacity, average_time;

        String name = "Sunway Pyramid";
        area = 75 * 95;
        average_time = 50;
        id = 1;
        capacity = 445; //capacity is counted by the area divided by the 4 meter apart from each direction which forms a square to ensure can pass and maintain distance at least 2 feet apart at all times, hence the area of square can be calculated by 4*4 which gives the square meter of 16, hence (75*95)/16= the capacity of visitor it can fit
        System.out.println(id + ":" + name + ". " + "Area is " + area + ". " + "Average time per person is. " + average_time + " Capacity is " + capacity);
    }

    public void display2() { //second floor of sunway pyramid
        int id, area, capacity, average_time;

        String name = "Sunway Pyramid";
        area = 75 * 95;
        average_time = 50;
        id = 2;
        capacity = 445;
        System.out.println(id + ":" + name + ". " + "Area is " + area + ". " + "Average time per person is. " + average_time + " Capacity is " + capacity);
    }

    public void display3() { //third floor of sunway pyramid
        int id, area, capacity, average_time;

        String name = "Sunway Pyramid";
        area = 75 * 95;
        average_time = 50;
        id = 3;
        capacity = 445;
        System.out.println(id + ":" + name + ". " + "Area is " + area + ". " + "Average time per person is. " + average_time + " Capacity is " + capacity);
    }

    public void display4() { //fourth floor of sunway pyramid
        int id, area, capacity, average_time;

        String name = "Sunway Pyramid";
        area = 75 * 95;
        average_time = 50;
        id = 4;
        capacity = 445;
        System.out.println(id + ":" + name + ". " + "Area is " + area + ". " + "Average time per person is. " + average_time + " Capacity is " + capacity);
    }

    public void display5() { //fifth floor of sunway pyramid
        int id, area, capacity, average_time;

        String name = "Sunway Pyramid";
        area = 75 * 95;
        average_time = 50;
        id = 5;
        capacity = 445;
        System.out.println(id + ":" + name + ". " + "Area is " + area + ". " + "Average time per person is. " + average_time + " Capacity is " + capacity);
    }
}
class SocialBubble{ //inheritance class
    public void socialpractice(int n, int s, int w, int e, int c)
    { //task 3 when either direction is below 6 feet, n = north, s = south, e = east, w = west
        int north, south, west, east;
        if(n<12)
        {
            north = 12-n;
            System.out.println("Please move away from North by " + north + " feet");
        }
        if(s<12)
        {
            south = 12-s;
            System.out.println("Please move away from South by " + south + " feet");
        }
        if(e<12)
        {
            east = 12-e;
            System.out.println("Please move away from East by " + east + " feet");
        }
        if(w<12)
        {
            west = 12-w;
            System.out.println("Please move away from West by " + west + " feet");
        }
        System.out.println("You are currently in a close contact. Hence, your status will be set as casual contact.");
        if(c == 1) { //comparing the choice of input with the floor level from the main function in order to know the floor level of location and to display the student id, status and etc
            System.out.println("20306220, Yeoh Zi Song. ID: 1, Sunway Pyramid, 7/3/2022, 3pm, Status: Casual Contact.");
        }
        else if (c == 2){
            System.out.println("20306220, Yeoh Zi Song. ID: 2, Sunway Pyramid, 7/3/2022, 3pm, Status: Casual Contact.");
        }
        else if (c == 3){
            System.out.println("20306220, Yeoh Zi Song. ID: 3, Sunway Pyramid, 7/3/2022, 3pm, Status: Casual Contact.");
        }
        else if (c == 4){
            System.out.println("20306220, Yeoh Zi Song. ID: 4, Sunway Pyramid, 7/3/2022, 3pm, Status: Casual Contact.");
        }
        else
            System.out.println("20306220, Yeoh Zi Song. ID: 5, Sunway Pyramid, 7/3/2022, 3pm, Status: Casual Contact.");
    }
}
public class ProactiveSD extends SocialBubble{ //main class that inherits SocialBubble
    public static void main(String[] args) { //main function
        LocationDatabase obj = new LocationDatabase(); //invoke the class LocationDatabase to be able to display the locations
        ProactiveSD ih = new ProactiveSD(); //invoke the inheriting class of ProactiveSD to access the objects
        obj.display1();
        obj.display2();
        obj.display3();
        obj.display4();
        obj.display5();
        Scanner keyboard = new Scanner(System.in); //to take input from user
        System.out.println("Please choose your location by indicating the id");
        int choice = keyboard.nextInt(); //input of user assigned to choice
        int distance_north, distance_south, distance_west, distance_east;
        int totaldistance;
        Random rand = new Random();
        int visitors = rand.nextInt(446); //generating random visitors every run, with 1782 being upper boundary due to upperbound-1 is the default of rand()
        System.out.println("Choice chosen is " + choice);

        while(choice > 5 || choice < 1 ){ //if the choice of user is not either the floor levels displayed, user gets to input again their choice again
            System.out.println("Invalid location id, please key in a new location id again");
            choice = keyboard.nextInt();
        }

        while(visitors >= 445){ //if the visitors have reached the limit, user gets to choose to input again their choice or to wait for people to exit.
            System.out.println("The maximum capacity has been reached, the average time per person is 50 minutes. Would you like to wait? If no please reselect your location again. If yes please key in 0 as your next choice and you will be queued up for the location you desire.");
            choice = keyboard.nextInt(); //if user chooses to pick other locations, a new input is obtained from the user
            if (choice == 0 ){ //if the user decides to queue up and wait when the visitors have reached the limit
                System.out.println("Queueing up");
                break; //ends here if the user decides to wait until one of the visitor exits
            }
            System.out.println("Choice chosen again is " + choice);
            visitors = rand.nextInt(446);//generate a new visitor number as each floor level have different visitors
            System.out.println( " " + visitors);
        }
        System.out.println( "Today's visitors are " + visitors);
        if(choice == 1) { //if floor level one is chosen
            obj.display1(); //displays the information of floor level one of sunway pyramid
                System.out.println("Please key in distance(feet) from other people in all four directions."); //obtaining the 4 directions feet
                distance_north = keyboard.nextInt(); //north direction apart from the visitor in front of user
                distance_south = keyboard.nextInt(); //south direction apart from the visitor in front of user
                distance_east = keyboard.nextInt(); //east direction apart from the visitor in front of user
                distance_west = keyboard.nextInt(); //west direction apart from the visitor in front of user
                totaldistance = distance_north+distance_south+distance_east+distance_west; //to count the total feet from each direction and pass it back to inheritance class SocialBubble
                if(totaldistance >= 48) //if each direction is at least 12 feet apart according to the requirement of assignment, hence the average feet of each direction must be at least 12 hence the sum of total feet from each direction must be 48 and above
                {
                    System.out.println("Appreciation for your effort in keeping social distancing");
                }
                else //if one of the direction feet is less than 12 then the sum of feet from each direction would be lesser than 48 and pass it back to SocialBubble to alert user to stand farther from which direction by how many feet
                {
                    ih.socialpractice(distance_north, distance_south, distance_east, distance_west, choice);
                }
            }


            else if(choice == 2) { //if floor level 2 is chosen
            obj.display2(); //displays the information of floor level two of sunway pyramid
                System.out.println("Please key in distance(feet) from other people in all four directions.");
                distance_north = keyboard.nextInt();
                distance_south = keyboard.nextInt();
                distance_east = keyboard.nextInt();
                distance_west = keyboard.nextInt();
                totaldistance = distance_north+distance_south+distance_east+distance_west;
                if(totaldistance >= 48)
                {
                    System.out.println("Appreciation for your effort in keeping social distancing");
                }
                else
                {
                    ih.socialpractice(distance_north, distance_south, distance_east, distance_west, choice);
                }
        }

            else if(choice == 3) { //if floor level 3 is chosen
            obj.display3(); //displays the information of floor level three of sunway pyramid
                System.out.println("Please key in distance(feet) from other people in all four directions.");
                distance_north = keyboard.nextInt();
                distance_south = keyboard.nextInt();
                distance_east = keyboard.nextInt();
                distance_west = keyboard.nextInt();
                totaldistance = distance_north+distance_south+distance_east+distance_west;
                if(totaldistance >= 48)
                {
                    System.out.println("Appreciation for your effort in keeping social distancing");
                }
                else
                {
                    ih.socialpractice(distance_north, distance_south, distance_east, distance_west, choice);
                }
        }

            else if(choice == 4){ //if floor level four is chosen
            obj.display4(); //displays the information of floor level four of sunway pyramid
                System.out.println("Please key in distance(feet) from other people in all four directions.");
                distance_north = keyboard.nextInt();
                distance_south = keyboard.nextInt();
                distance_east = keyboard.nextInt();
                distance_west = keyboard.nextInt();
                totaldistance = distance_north+distance_south+distance_east+distance_west;
                if(totaldistance >= 48)
                {
                    System.out.println("Appreciation for your effort in keeping social distancing");
                }
                else
                {
                    ih.socialpractice(distance_north, distance_south, distance_east, distance_west, choice);
                }

        }

            else{ //if floor level five is chosen (else can be used in this case as the situation whereby if choice of floor levels is outside the range of 1~5 would prompt user input of choice again)
                obj.display5();//displays information of floor level five of sunway pyramid
                System.out.println("Please key in distance(feet) from other people in all four directions.");
                distance_north = keyboard.nextInt();
                distance_south = keyboard.nextInt();
                distance_east = keyboard.nextInt();
                distance_west = keyboard.nextInt();
                totaldistance = distance_north+distance_south+distance_east+distance_west;
                if(totaldistance >= 48)
                {
                    System.out.println("Appreciation for your effort in keeping social distancing");
                }
                else
                {
                    ih.socialpractice(distance_north, distance_south, distance_east, distance_west, choice);
                }
            }
    }
}
